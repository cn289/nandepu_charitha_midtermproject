# src/io_utils.py
import pandas as pd
from typing import List, Set
from itertools import chain

def load_transactions(csv_path: str) -> List[Set[str]]:
    """
    Reads a CSV with columns: TID,Items
    'Items' is a quoted, comma-separated list (we already created this format).
    Returns a list of Python sets, one set per transaction.
    """
    df = pd.read_csv(csv_path)
    txs: List[Set[str]] = []
    for s in df["Items"].astype(str):
        items = [x.strip() for x in s.split(",") if x.strip()]
        txs.append(set(items))
    return txs

def one_hot_encode(transactions: List[Set[str]]) -> pd.DataFrame:
    """
    Makes a DataFrame with one column per unique item, and 0/1 per transaction.
    Required by mlxtend's Apriori/FP-Growth.
    """
    all_items = sorted(set(chain.from_iterable(transactions)))
    rows = []
    for t in transactions:
        rows.append({item:bool(item in t) for item in all_items})
    return pd.DataFrame(rows)

def support(itemset: Set[str], transactions: List[Set[str]]) -> float:
    """
    Support = (# transactions containing the itemset) / (total transactions)
    """
    if not itemset:
        return 0.0
    count = sum(1 for t in transactions if itemset.issubset(t))
    return count / len(transactions)
