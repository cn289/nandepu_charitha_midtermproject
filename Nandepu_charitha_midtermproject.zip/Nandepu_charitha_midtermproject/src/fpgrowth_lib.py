# src/fpgrowth_lib.py
import pandas as pd
from mlxtend.frequent_patterns import fpgrowth, association_rules

def run_fpgrowth(onehot_df: pd.DataFrame, minsup: float, minconf: float):
    # Run FP-Growth algorithm
    freq = fpgrowth(onehot_df, min_support=minsup, use_colnames=True)

    # Keep the original 'itemsets' column (needed for association_rules)
    # Add a readable tuple version
    freq["itemset"] = freq["itemsets"].apply(lambda s: tuple(sorted(list(s))))

    # Generate association rules using the original freq DataFrame
    rules_df = association_rules(freq, metric="confidence", min_threshold=minconf)

    # Clean the rule columns for readability
    rules_df["antecedent"] = rules_df["antecedents"].apply(lambda s: tuple(sorted(list(s))))
    rules_df["consequent"] = rules_df["consequents"].apply(lambda s: tuple(sorted(list(s))))
    rules_df = rules_df[["antecedent", "consequent", "support", "confidence"]]

    # Sort both outputs for nicer viewing
    freq = freq[["itemset", "support"]].sort_values(by=["support"], ascending=False).reset_index(drop=True)
    rules_df = rules_df.sort_values(by=["confidence", "support"], ascending=[False, False]).reset_index(drop=True)

    return freq, rules_df
