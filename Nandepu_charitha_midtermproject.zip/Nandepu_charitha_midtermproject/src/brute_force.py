# src/brute_force.py
from itertools import combinations
from typing import List, Set, Dict, Tuple
from src.io_utils import support

def enumerate_frequent_itemsets(transactions: List[Set[str]], minsup: float) -> Dict[frozenset, float]:
    """
    Brute force: try all k-itemsets (k=1..K). Keep those with support >= minsup.
    Stop when a k produces no frequent itemsets.
    Returns {itemset_frozenset: support}.
    """
    items = sorted(set().union(*transactions))
    freq: Dict[frozenset, float] = {}
    k = 1
    while True:
        level_itemsets = [set(c) for c in combinations(items, k)]
        level_freq = {}
        for s in level_itemsets:
            sup = support(s, transactions)
            if sup >= minsup:
                level_freq[frozenset(s)] = sup
        if not level_freq:
            break
        freq.update(level_freq)
        k += 1
    return freq

def generate_rules(freq_itemsets: Dict[frozenset, float], minconf: float) -> List[Tuple[Set[str], Set[str], float, float]]:
    """
    Generate rules X -> Y for every frequent L where X ∪ Y = L and X ∩ Y = ∅.
    Return list of (X, Y, support(L), confidence).
    """
    rules = []
    for L, suppL in freq_itemsets.items():
        Lset = set(L)
        if len(Lset) < 2:
            continue

        def nonempty_proper_subsets(s):
            for r in range(1, len(s)):
                for combo in combinations(s, r):
                    yield set(combo)

        for X in nonempty_proper_subsets(Lset):
            Y = Lset - X
            if not Y:
                continue
            suppX = freq_itemsets.get(frozenset(X))
            if not suppX:
                continue
            conf = suppL / suppX
            if conf >= minconf:
                rules.append((X, Y, suppL, conf))

    rules.sort(key=lambda r: (-r[3], -r[2], len(r[0]) + len(r[1])))
    return rules
