# run_all.py
import os
import pandas as pd
from src.io_utils import load_transactions, one_hot_encode
from src.brute_force import enumerate_frequent_itemsets, generate_rules
from src.apriori_lib import run_apriori
from src.fpgrowth_lib import run_fpgrowth


def validate_prob(prompt):
    """Ask user for a number between 0 and 1."""
    while True:
        s = input(prompt).strip()
        try:
            v = float(s)
            if 0.0 <= v <= 1.0:
                return v
        except:
            pass
        print(" Please enter a number between 0 and 1.")


def choose_dataset(data_dir="data"):
    """Let user select one of the CSV datasets."""
    files = [f for f in sorted(os.listdir(data_dir)) if f.endswith(".csv")]
    print("\n Available datasets:")
    for i, f in enumerate(files, 1):
        print(f"  {i}) {f}")
    while True:
        s = input(f"Enter 1..{len(files)}: ").strip()
        if s.isdigit() and 1 <= int(s) <= len(files):
            return os.path.join(data_dir, files[int(s)-1])
        print(" Invalid choice, try again.")


if __name__ == "__main__":
    print("=== CS634 Midterm Project ===")
    data_path = choose_dataset()
    minsup = validate_prob("Enter minimum support (0..1): ")
    minconf = validate_prob("Enter minimum confidence (0..1): ")

    # --- Load and prepare data ---
    txs = load_transactions(data_path)
    onehot = one_hot_encode(txs)
    base = os.path.splitext(os.path.basename(data_path))[0]
    out_dir = os.path.join("outputs", base)
    os.makedirs(out_dir, exist_ok=True)

    print(f"\n Dataset: {base}")
    print(f"Transactions: {len(txs)} | minsup = {minsup:.2f}, minconf = {minconf:.2f}")

    # --- Brute Force ---
    print("\n=== Brute Force ===")
    L = enumerate_frequent_itemsets(txs, minsup)
    rules = generate_rules(L, minconf)
    print(f"Frequent itemsets: {len(L)} | Rules: {len(rules)}")

    # Show a few rules for screenshots
    print("\nSample Rules from Brute Force:")
    if rules:
        for i, r in enumerate(rules[:5]):
            X, Y, s, c = r
            print(f" Rule {i+1}: {set(X)} -> {set(Y)}")
            print(f"  Support: {s:.2f}, Confidence: {c:.2f}")
    else:
        print("  No rules found at this support/confidence.")

    # Save Brute Force results
    pd.DataFrame(
        [{"itemset": "{" + ", ".join(sorted(k)) + "}", "support": v} for k, v in L.items()]
    ).sort_values(by=["support"], ascending=False).to_csv(
        os.path.join(out_dir, "bruteforce_itemsets.csv"), index=False
    )

    pd.DataFrame(
        [{"antecedent": "{" + ", ".join(sorted(a)) + "}",
          "consequent": "{" + ", ".join(sorted(b)) + "}",
          "support": s, "confidence": c}
         for (a, b, s, c) in rules]
    ).to_csv(os.path.join(out_dir, "bruteforce_rules.csv"), index=False)

    # --- Apriori ---
    print("\n=== Apriori (mlxtend) ===")
    af, ar = run_apriori(onehot, minsup, minconf)
    print(f"Frequent itemsets: {len(af)} | Rules: {len(ar)}")

    print("\nSample Rules from Apriori:")
    if not ar.empty:
        for i, row in ar.head(5).iterrows():
            a = row.get("antecedents", row.get("antecedent", "N/A"))
            b = row.get("consequents", row.get("consequent", "N/A"))
            supp = row.get("support", 0)
            conf = row.get("confidence", 0)
            print(f" Rule {i+1}: {set(a)} -> {set(b)}")
            print(f"  Support: {supp:.2f}, Confidence: {conf:.2f}")
    else:
        print("  No rules found at this support/confidence.")

    af.to_csv(os.path.join(out_dir, "apriori_itemsets.csv"), index=False)
    ar.to_csv(os.path.join(out_dir, "apriori_rules.csv"), index=False)

    # --- FP-Growth ---
    print("\n=== FP-Growth (mlxtend) ===")
    ff, fr = run_fpgrowth(onehot, minsup, minconf)
    print(f"Frequent itemsets: {len(ff)} | Rules: {len(fr)}")

    print("\nSample Rules from FP-Growth:")
    if not fr.empty:
        for i, row in fr.head(5).iterrows():
            a = row.get("antecedents", row.get("antecedent", "N/A"))
            b = row.get("consequents", row.get("consequent", "N/A"))
            supp = row.get("support", 0)
            conf = row.get("confidence", 0)
            print(f" Rule {i+1}: {set(a)} -> {set(b)}")
            print(f"  Support: {supp:.2f}, Confidence: {conf:.2f}")
    else:
        print("  No rules found at this support/confidence.")

    ff.to_csv(os.path.join(out_dir, "fpgrowth_itemsets.csv"), index=False)
    fr.to_csv(os.path.join(out_dir, "fpgrowth_rules.csv"), index=False)

    # --- Summary ---
    print("\nAll outputs saved to:", out_dir)
    print("Files generated:")
    for f in sorted(os.listdir(out_dir)):
        print("  -", f)
